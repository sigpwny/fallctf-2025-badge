import time
from logger import log
from framebuf import FrameBuffer, MONO_HMSB, RGB565
from boolpalette import BoolPalette

TYPE_CHECKING = False
if TYPE_CHECKING:
    from display import Display

global_buffer = bytearray(34 * 42 * 2)


class View:
    _changed = True
    _cache_x_y = (0, 0)
    _cache_w_h = (0, 0)

    def __init__(self, display):
        # type: (Display) -> None
        self.display = display
        self.start = time.time_ns()
        self._renders_count = 0

    def update(self, *data):
        pass

    def __setattr__(self, key, value):
        object.__setattr__(self, key, value)
        if not self._changed and key != "_changed":
            object.__setattr__(self, "_changed", True)

    def render(self):
        pass

    def render_x_y(self, x, y):
        pass

    def render_x_y_cache(self, x, y, enable_render_cache=False):
        if not enable_render_cache:
            self.render_x_y(x, y)
        else:
            if self._cache_x_y != (x, y) or self._changed:
                # ensure expected black background
                self.display.display.fill_rect(
                    self._cache_x_y[0],
                    self._cache_x_y[1],
                    self._cache_w_h[0],
                    self._cache_w_h[1],
                    0,
                )
                self.render_x_y(x, y)
                self._cache_x_y = (x, y)
                self._cache_w_h = self.get_width_height()
            self._changed = False

    def get_width_height(self) -> tuple[int, int]:
        return 0, 0

    def first_render(self):
        self.render()


class BasicTextView(View):
    def __init__(self, display, lines=[], shake_color=None):
        super().__init__(display)
        self.max_line = self.display.height // self.display.line_height
        self.lines = lines[: self.max_line]
        if shake_color is None:
            self.shake_color = self.display.display.tft.RED
        else:
            self.shake_color = shake_color
        self.shake_notice = 0

    def update(self, index, line):
        if 0 <= index < self.max_line:
            self._changed = True
            if index >= len(self.lines):
                self.lines.extend([""] * (index + 1 - len(self.lines)))
            self.lines[index] = line
        else:
            raise IndexError("Line index out of range")

    def shake(self, time=2, color=None):
        self.shake_notice = time
        if color is not None:
            self.shake_color = color

    def first_render(self):
        super().first_render()
        self.render(refresh_all=True)

    def render(self, refresh_all=False):
        super().render()
        for i, line in enumerate(self.lines):
            self.display.draw_text(0, i * self.display.line_height, line)

    def render_x_y(self, x, y):
        super().render()
        if self.shake_notice > 0:
            self.shake_notice -= 1
            # hacky way to make sure it continue rendering for next tick
            self._changed = True
            if self.shake_notice != 0:
                color = self.shake_color
            else:
                color = 0xFFFF
        else:
            color = 0xFFFF
        for i, line in enumerate(self.lines):
            self.display.draw_text(x, y + i * self.display.line_height, line, color)

    def get_width_height(self):
        return (
            max(len(line) for line in self.lines) * self.display.char_width,
            len(self.lines) * self.display.line_height,
        )


class FontTextView(View):
    def __init__(
        self,
        display,
        font_path,
        data: str = "",
        cache_index=False,
        color=None,
        x_spacing=1,
        y_spacing=1,
        rot=0,
    ):
        # type: (Display, str, str, bool, int|None, int, int, int) -> None
        super().__init__(display)
        self.color = color if color is not None else self.display.display.tft.WHITE
        from microfont import MicroFont

        self.font = MicroFont(font_path, cache_index=cache_index)
        self.data = ""
        self.x = 0
        self.y = 0
        self.x_pad = 0
        self.y_pad = 0
        self.x_spacing = x_spacing
        self.y_spacing = y_spacing
        self.rot = rot
        self.data = data

    def update(self, x, y, data: str):
        self.x_pad = x
        self.y_pad = y
        self.data = data

    def setColor(self, color):
        self.color = color

    def setRotation(self, rot):
        self.rot = rot

    def setSpacing(self, x_spacing, y_spacing):
        self.x_spacing = x_spacing
        self.y_spacing = y_spacing

    def render_x_y(self, x, y):
        self.x = x
        self.y = y
        self.render()

    def render(self):
        super().render()
        self.font.write(
            self.data,
            self.display.display.buffer,
            1,
            self.display.display.width,
            self.display.display.height,
            self.x + self.x_pad,
            self.y + self.y_pad,
            self.color,
            y_spacing=self.y_spacing,
            x_spacing=self.x_spacing,
            rot=self.rot,
        )

    def get_width_height(self):
        lines = self.data.split("\n")
        return (
            self.x_pad
            + max(len(line) for line in lines) * (self.font.max_width + self.x_spacing)
            - self.x_spacing,
            self.y_pad
            + len(lines) * (self.font.height + self.y_spacing)
            - self.y_spacing,
        )


def bitMapViewFromFile(display, file_path, width, height, x=0, y=0, **kwargs):
    # with open(file_path, "rb") as f:
    #     bitmap = bytearray(f.read())
    return BitMapView(display, None, width, height, x, y, filename=file_path, **kwargs)


class BitMapView(View):
    def __init__(
        self,
        display,
        bitmap,
        width,
        height,
        x=0,
        y=0,
        filename=None,
        format=MONO_HMSB,
        fg_color=None,
        bg_color=None,
    ):
        # type: (Display, bytearray, int, int, int, int, int, int|None, int|None) -> None
        super().__init__(display)
        if bitmap is not None:
            self.bitmap = FrameBuffer(bitmap, width, height, format)
        else:
            self.bitmap = None
        self.filename = filename
        self.x = x
        self.y = y
        self.palette = BoolPalette(RGB565)
        self.width = width
        self.height = height
        if fg_color is not None:
            self.palette.fg(fg_color)
        else:
            self.palette.fg(self.display.display.tft.WHITE)
        if bg_color is not None:
            self.palette.bg(bg_color)
        else:
            self.palette.bg(self.display.display.tft.BLACK)
        self.format = format
        self.rendered_once = False

    def set_colors(self, fg_color, bg_color):
        self.palette.fg(fg_color)
        self.palette.bg(bg_color)

    def update(self, *args, **kwargs):
        raise NotImplementedError("Update bitmap not implemented yet")

    def render_x_y(self, x, y):
        self.x = x
        self.y = y
        self.render()

    def render(self):
        if self.rendered_once:
            return
        self.rendered_once = True
        super().render()
        if self.bitmap is None:
            with open(self.filename, "rb") as f:
                global global_buffer
                f.readinto(global_buffer)
                bitmap = FrameBuffer(
                    global_buffer, self.width, self.height, self.format
                )
        else:
            bitmap = self.bitmap
        if self.format == RGB565:
            self.display.display.blit(bitmap, self.x, self.y)
        else:
            self.display.display.blit(bitmap, self.x, self.y, -1, self.palette)

    def get_width_height(self):
        return self.width, self.height


class UnboxedLine(View):
    x1 = 0
    y1 = 0
    x2 = 0
    y2 = 0

    def __init__(self, display, x1, y1, x2, y2, color=None):
        # type: (Display, int, int, int, int, int|None) -> None
        super().__init__(display)
        self._x1 = x1
        self._y1 = y1
        self._x2 = x2
        self._y2 = y2
        self.color = color if color is not None else self.display.display.tft.WHITE

    def update(self, x1, y1, x2, y2):
        self._x1 = x1
        self._y1 = y1
        self._x2 = x2
        self._y2 = y2

    def set_color(self, color):
        self.color = color

    def render_x_y(self, x, y):
        self.x1 = self._x1 + x
        self.y1 = self._y1 + y
        self.x2 = self._x2 + x
        self.y2 = self._y2 + y
        self.render()

    def render(self):
        super().render()
        self.display.display.line(self.x1, self.y1, self.x2, self.y2, self.color)

    def get_width_height(self):
        return 0, 0


class PBar(View):
    def __init__(
        self,
        display,
        capacity,
        initial_value=0,
        # theme=0,
        width=100,
        height=10,
        direction=0,  # 0: horizontal, 1: vertical
        fg_color=None,
        text_mode=0,  # 0: no text, 1: value, 2: changes from initial value
    ):
        # type: (Display, int, int, int, int, int, int|None, int) -> None
        super().__init__(display)
        self.capacity = capacity
        if text_mode == 2:
            self.i_val = initial_value
        self.value = initial_value
        # self.theme = theme
        self.width = width
        self.height = height
        self.fg_color = (
            fg_color if fg_color is not None else self.display.display.tft.WHITE
        )
        self.shake_color = self.display.display.tft.RED
        self.direction = direction
        self.shake_notice = 0
        self.text_mode = text_mode
        self.text = ""
        if self.text_mode == 1:
            self.text = f"{self.value}"
        elif self.text_mode == 2:
            self.text = f"+0"

    def update(self, value, initial_value=None):
        if initial_value is not None and self.text_mode == 2:
            self.i_val = initial_value
        if 0 <= value <= self.capacity:
            self.value = value
            return 0
        else:
            return -1

    def set_color(self, color):
        self.fg_color = color

    def shake(self, color=None, time=2):
        if color is not None:
            self.shake_color = color
        self.shake_notice = time

    def get_width_height(self):
        return (
            self.width + len(self.text) * self.display.char_width + 5 + 1,
            self.height,
        )

    def render_x_y(self, x, y):
        self.x = x
        self.y = y
        self.render()

    def render(self):
        super().render()
        # default theme like a health bar with border. If shake_notice > 0, draw a red border
        if self.shake_notice > 0:
            self.shake_notice -= 1
            if self.shake_notice != 0:
                border_color = self.shake_color
            else:
                border_color = self.fg_color
            # hacky way to make sure it continue rendering for next tick
            self._changed = True
        else:
            border_color = self.fg_color
        self.display.display.rect(self.x, self.y, self.width, self.height, border_color)
        if self.direction == 0:
            fill_width = int(self.width * self.value / self.capacity)
            self.display.display.fill_rect(
                self.x + 1, self.y + 1, fill_width - 2, self.height - 2, self.fg_color
            )
            self.display.display.fill_rect(
                self.x + 1 + fill_width,
                self.y + 1,
                self.width - 2 - fill_width,
                self.height - 2,
                self.display.display.tft.BLACK,
            )
        else:
            fill_height = int(self.height * self.value / self.capacity)
            self.display.display.fill_rect(
                self.x + 1,
                self.y + self.height - fill_height + 1,
                self.width - 2,
                fill_height - 2,
                self.fg_color,
            )
            self.display.display.fill_rect(
                self.x + 1,
                self.y + 1,
                self.width - 2,
                self.height - 2 - fill_height,
                self.display.display.tft.BLACK,
            )
        # draw number after whole bar in right
        if self.text_mode == 1:
            self.text = f"{self.value}"
        elif self.text_mode == 2:
            self.text = f"{self.value - self.i_val:+d}"
        self.display.draw_text(
            self.x + self.width + 5,
            self.y + (self.height - self.display.line_height) // 2,
            self.text,
        )
